# PrestaShop Promozioni con Countdown

Modulo per PrestaShop 1.7.8+ per creare promozioni con countdown timer.

## ⚡ Caratteristiche

- 🔍 Filtri avanzati per selezione prodotti
- 📱 Immagini prodotti per identificazione  
- ⏰ Countdown dinamico in tempo reale
- 🎯 Categorie automatiche
- 📱 Design responsive

## 🚀 Installazione

1. Carica la cartella "promotionscountdown" in `/modules/`
2. Installa dal BackOffice PrestaShop
3. Configura le promozioni!

Sviluppato con ❤️
